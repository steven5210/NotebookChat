var express = require('express');
var app = express();
app.get('/', function(req, res){
	res.render('index', {title: "Group Chat"});
})

app.set('views', __dirname + '/views');
app.set('view engine', 'ejs');

var server = app.listen(9000, function(){
	console.log('Listening on port over 9000!');
})
var users = {};
var messages = [];

var io = require('socket.io').listen(server)
io.sockets.on('connection', function(socket){

	socket.on('a_new_user', function(name){
		users[socket.id] = name
		io.emit('new_user', name, messages)
	})
	socket.on('post_message', function(message){
		messages.push(users[socket.id] +" said: " + message.message)
		console.log(messages);
		io.emit('new_message', users[socket.id], message)
	})
	socket.on('disconnect', function(){
		io.emit('user_dis', users[socket.id])
	})

})